// main/hello_world_main.c
// Esteira + Touch (polling robusto) — mapeado para T0, T4, T9
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "esp_timer.h"
#include "esp_log.h"
#include "driver/touch_pad.h"

#define TAG "ESTEIRA"

// ====== Touch pads (mapeados para T0, T4, T9) ======
#define TP_OBJ   TOUCH_PAD_NUM0   // T0  (GPIO4)
#define TP_HMI   TOUCH_PAD_NUM4   // T4  (GPIO13)
#define TP_ESTOP TOUCH_PAD_NUM9   // T9  (GPIO32)

// ====== Periodicidade, prioridades, stack ======
#define ENC_T_MS        5
#define PRIO_ESTOP      5
#define PRIO_ENC        4
#define PRIO_CTRL       3
#define PRIO_SORT       3
#define STK             3072

// ====== Polling config ======
#define TOUCH_FILTER_CYCLES 10      // filtro (start)
#define TOUCH_BASELINE_SAMPLES 20   // quantas amostras para média de baseline
#define TOUCH_POLL_MS 80            // intervalo de polling (ms)
#define TOUCH_THRESH_FRACT 0.70f    // threshold = baseline * FRACT

// ====== Handles/IPC ======
static TaskHandle_t hENC = NULL, hCTRL = NULL, hSORT = NULL, hSAFE = NULL;
static TaskHandle_t hCtrlNotify = NULL;
typedef struct { int64_t t_evt_us; } sort_evt_t;
static QueueHandle_t qSort = NULL;
static SemaphoreHandle_t semEStop = NULL;
static SemaphoreHandle_t semHMI   = NULL;

// ====== Estado simulado da esteira ======
typedef struct {
    float rpm;
    float pos_mm;
    float set_rpm;
} belt_state_t;
static belt_state_t g_belt = { .rpm = 0.f, .pos_mm = 0.f, .set_rpm = 120.0f };

// ====== Busy-loop previsível (~WCET) ======
static inline void cpu_tight_loop_us(uint32_t us)
{
    int64_t start = esp_timer_get_time();
    while ((esp_timer_get_time() - start) < (int64_t)us) {
        __asm__ __volatile__("nop");
    }
}

// ====== Controle simples e tarefas (mantive sua lógica) ======
static void IRAM_ATTR touch_dummy_isr(void *arg) { /* não usamos ISR nesta versão */ }

// ENC_SENSE
static void task_enc_sense(void *arg)
{
    TickType_t next = xTaskGetTickCount();
    TickType_t T = pdMS_TO_TICKS(ENC_T_MS);
    if (T == 0) T = 1;
    for (;;) {
        float err = g_belt.set_rpm - g_belt.rpm;
        g_belt.rpm += 0.05f * err;
        g_belt.pos_mm += (g_belt.rpm / 60.0f) * (ENC_T_MS / 1000.0f) * 100.0f;
        if (g_belt.rpm > 200.0f) g_belt.rpm = 200.0f;
        if (g_belt.set_rpm > 200.0f) g_belt.set_rpm = 200.0f;
        cpu_tight_loop_us(700);
        if (hCtrlNotify) xTaskNotifyGive(hCtrlNotify);
        vTaskDelayUntil(&next, T);
    }
}

// SPD_CTRL
static void task_spd_ctrl(void *arg)
{
    float kp = 0.4f, ki = 0.1f, integ = 0.f;
    for (;;) {
        ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
        float err = g_belt.set_rpm - g_belt.rpm;
        integ += err * (ENC_T_MS / 1000.0f);
        float u = kp * err + ki * integ;
        g_belt.set_rpm += 0.1f * u;
        if (g_belt.set_rpm > 200.0f) g_belt.set_rpm = 200.0f;
        if (g_belt.set_rpm < 0.0f) g_belt.set_rpm = 0.0f;
        cpu_tight_loop_us(1200);
        if (xSemaphoreTake(semHMI, 0) == pdTRUE) {
            ESP_LOGI(TAG, "[HMI] Interação detectada. rpm=%.1f set=%.1f pos=%.1fmm",
                     g_belt.rpm, g_belt.set_rpm, g_belt.pos_mm);
        }
    }
}

// SORT_ACT
static void task_sort_act(void *arg)
{
    sort_evt_t ev;
    for (;;) {
        if (xQueueReceive(qSort, &ev, portMAX_DELAY) == pdTRUE) {
            int64_t t0 = esp_timer_get_time();
            cpu_tight_loop_us(700);
            int64_t dt = esp_timer_get_time() - t0;
            int64_t lat = t0 - ev.t_evt_us;
            ESP_LOGI(TAG, "[SORT] Objeto detectado. evt_ts=%lld lat=%lld us act=%lld us",
                     (long long)ev.t_evt_us, (long long)lat, (long long)dt);
        }
    }
}

// SAFETY_TASK
static void task_safety(void *arg)
{
    for (;;) {
        if (xSemaphoreTake(semEStop, portMAX_DELAY) == pdTRUE) {
            int64_t t0 = esp_timer_get_time();
            g_belt.set_rpm = 0.f;
            cpu_tight_loop_us(900);
            int64_t dt = esp_timer_get_time() - t0;
            ESP_LOGW(TAG, "[E-STOP] Emergência! Esteira parada. dur=%lld us", (long long)dt);
        }
    }
}

// HEARTBEAT (status + raw)
// ====== HEARTBEAT ======
static void task_heartbeat(void *arg)
{
    for (;;) {
        ESP_LOGI(TAG, "[STATUS] rpm=%.1f | set=%.1f | pos=%.1f mm",
                 g_belt.rpm, g_belt.set_rpm, g_belt.pos_mm);
        vTaskDelay(pdMS_TO_TICKS(200));  // antes era 2000 ms, agora 200 ms
    }
}

// ====== TASK: polling robusto para touch (usa filtered values) ======
static void task_touch_poll(void *arg)
{
    // calibramos baseline: média de N amostras filtradas
    uint32_t sum0 = 0, sum4 = 0, sum9 = 0;
    uint16_t tmp0, tmp4, tmp9;
    for (int i = 0; i < TOUCH_BASELINE_SAMPLES; ++i) {
        touch_pad_read_filtered(TP_OBJ, &tmp0);
        touch_pad_read_filtered(TP_HMI, &tmp4);
        touch_pad_read_filtered(TP_ESTOP, &tmp9);
        sum0 += tmp0; sum4 += tmp4; sum9 += tmp9;
        vTaskDelay(pdMS_TO_TICKS(50)); // pequena espera para filtro estabilizar entre amostras
    }
    uint16_t base0 = sum0 / TOUCH_BASELINE_SAMPLES;
    uint16_t base4 = sum4 / TOUCH_BASELINE_SAMPLES;
    uint16_t base9 = sum9 / TOUCH_BASELINE_SAMPLES;

    uint16_t thresh0 = (uint16_t)(base0 * TOUCH_THRESH_FRACT);
    uint16_t thresh4 = (uint16_t)(base4 * TOUCH_THRESH_FRACT);
    uint16_t thresh9 = (uint16_t)(base9 * TOUCH_THRESH_FRACT);

    ESP_LOGI(TAG, "Touch baseline: T0=%u T4=%u T9=%u", base0, base4, base9);
    ESP_LOGI(TAG, "Touch thresholds: T0=%u T4=%u T9=%u (fract=%.2f)",
             thresh0, thresh4, thresh9, TOUCH_THRESH_FRACT);

    bool prev0 = false, prev4 = false, prev9 = false;

    for (;;) {
        touch_pad_read_filtered(TP_OBJ, &tmp0);
        touch_pad_read_filtered(TP_HMI, &tmp4);
        touch_pad_read_filtered(TP_ESTOP, &tmp9);

        bool cur0 = (tmp0 < thresh0);
        bool cur4 = (tmp4 < thresh4);
        bool cur9 = (tmp9 < thresh9);

        // detecção de borda (press)
        if (cur0 && !prev0) {
            sort_evt_t ev = { .t_evt_us = esp_timer_get_time() };
            xQueueSend(qSort, &ev, 0);
            ESP_LOGI(TAG, "[POLL] T0 touch -> queued SORT");
        }
        if (cur4 && !prev4) {
            xSemaphoreGive(semHMI);
            ESP_LOGI(TAG, "[POLL] T4 touch -> HMI");
        }
        if (cur9 && !prev9) {
            xSemaphoreGive(semEStop);
            ESP_LOGI(TAG, "[POLL] T9 touch -> E-STOP");
        }

        prev0 = cur0; prev4 = cur4; prev9 = cur9;
        vTaskDelay(pdMS_TO_TICKS(TOUCH_POLL_MS));
    }
}

// ====== Inicialização dos touch pads (filtro + config básica) ======
static void touch_pads_setup_for_polling(void)
{
    ESP_ERROR_CHECK(touch_pad_init());
    // configuramos canais com threshold 0 (vamos usar filtered values e thresholds calculados)
    touch_pad_config(TP_OBJ, 0);
    touch_pad_config(TP_HMI, 0);
    touch_pad_config(TP_ESTOP, 0);

    // start filter (filtra e permite uso de touch_pad_read_filtered)
    ESP_ERROR_CHECK(touch_pad_filter_start(TOUCH_FILTER_CYCLES));

    // NÃO registramos ISR aqui (usamos polling)
    touch_pad_clear_status();
    ESP_LOGI(TAG, "Touch pads iniciados para polling (filtro ativado).");
}

// ====== app_main ======
void app_main(void)
{
    ESP_LOGI(TAG, "=== Sistema ESTEIRA iniciado ===");

    // criar IPCs
    semEStop = xSemaphoreCreateBinary();
    semHMI   = xSemaphoreCreateBinary();
    qSort    = xQueueCreate(16, sizeof(sort_evt_t));

    // tasks principais
    xTaskCreatePinnedToCore(task_safety,   "SAFETY",   STK, NULL, PRIO_ESTOP, &hSAFE, 0);
    xTaskCreatePinnedToCore(task_enc_sense,"ENC_SENSE",STK, NULL, PRIO_ENC,   &hENC,  0);
    xTaskCreatePinnedToCore(task_spd_ctrl, "SPD_CTRL", STK, NULL, PRIO_CTRL,  &hCTRL, 0);
    xTaskCreatePinnedToCore(task_sort_act, "SORT_ACT", STK, NULL, PRIO_SORT,  &hSORT, 0);
    xTaskCreatePinnedToCore(task_heartbeat,"HEARTBEAT",2048, NULL, 1, NULL,   0);

    hCtrlNotify = hCTRL;

    // setup touch para polling
    touch_pads_setup_for_polling();

    // cria a task de polling (fica lendo filtered values e detecta toques)
    xTaskCreatePinnedToCore(task_touch_poll, "TOUCH_POLL", 3072, NULL, 2, NULL, 0);

    ESP_LOGI(TAG, "=== Setup completo ===");
}
