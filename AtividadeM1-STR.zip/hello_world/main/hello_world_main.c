// main/hello_world_main.c
// Esteira + Touch (polling robusto) + testes de políticas (RM/DM/Custom)
// Compilar com ESP-IDF. Para permitir set_cpu_freq_mhz() via esp_pm_configure,
// habilite CONFIG_PM_ENABLE no menuconfig.

#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <inttypes.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "freertos/portmacro.h"    // <- declarações relacionadas a ISR context
#include "esp_timer.h"
#include "esp_log.h"
#include "driver/touch_pad.h"
#include "esp_system.h"

#ifdef CONFIG_PM_ENABLE
#include "esp_pm.h"
#endif

#define TAG "ESTEIRA"

// ====== Compatibilidade: xPortIsInsideInterrupt / xPortInIsrContext ======
// Alguns ports usam xPortIsInsideInterrupt(), outros xPortInIsrContext().
// Garantimos que haja uma definição para xPortIsInsideInterrupt.
#ifndef xPortIsInsideInterrupt
    #ifdef xPortInIsrContext
        #define xPortIsInsideInterrupt xPortInIsrContext
    #else
        // fallback conservador: declarar função que retorna pdFALSE (não em ISR).
        // Isso evita implicit declaration warnings, mas se você chamar essa
        // função dentro de ISR o resultado será incorreto. Normalmente não é o caso
        // para a chamada que usamos (apenas para evitar mutex em ISR).
        static inline BaseType_t xPortIsInsideInterrupt(void) { return pdFALSE; }
    #endif
#endif

// ====== Configurações ======
#define TP_OBJ   TOUCH_PAD_NUM0   // T0  (GPIO4)
#define TP_HMI   TOUCH_PAD_NUM4   // T4  (GPIO13)
#define TP_ESTOP TOUCH_PAD_NUM9   // T9  (GPIO32)

#define ENC_T_MS        5
#define PRIO_ESTOP_DEF  6
#define PRIO_ENC_DEF    5
#define PRIO_CTRL_DEF   4
#define PRIO_SORT_DEF   4
#define PRIO_HEART_DEF  1
#define PRIO_TOUCH_DEF  2
#define STK             3072

#define TOUCH_FILTER_CYCLES 10
#define TOUCH_BASELINE_SAMPLES 20
#define TOUCH_POLL_MS 80
#define TOUCH_THRESH_FRACT 0.70f

// Escolha a política de teste: 0 = RM, 1 = DM, 2 = CUSTOM
#define TEST_POLICY 2

// Frequências a testar (MHz) — tente aplicar se power management estiver disponível.
// Use 80, 160 ou 240 conforme necessidade.
#define TEST_CPU_FREQ_MHZ 160

// ====== Handles/IPC ======
static TaskHandle_t hENC = NULL, hCTRL = NULL, hSORT = NULL, hSAFE = NULL;
static TaskHandle_t hHEART = NULL, hTOUCH = NULL;
static TaskHandle_t hCtrlNotify = NULL;
typedef struct { int64_t t_evt_us; int64_t deadline_us; } sort_evt_t;
static QueueHandle_t qSort = NULL;
static SemaphoreHandle_t semEStop = NULL;
static SemaphoreHandle_t semHMI   = NULL;

// ====== Estado simulado da esteira ======
typedef struct {
    float rpm;
    float pos_mm;
    float set_rpm;
} belt_state_t;
static belt_state_t g_belt = { .rpm = 0.f, .pos_mm = 0.f, .set_rpm = 120.0f };

// ====== Busy-loop previsível (~WCET) ======
static inline void cpu_tight_loop_us(uint32_t us)
{
    int64_t start = esp_timer_get_time();
    while ((esp_timer_get_time() - start) < (int64_t)us) {
        __asm__ __volatile__("nop");
    }
}

// ====== Instrumentação para métricas ======
static volatile uint32_t misses_enc = 0;
static volatile uint32_t misses_sort = 0;
static volatile uint32_t misses_ctrl = 0;

// soma do tempo ocupado (em microsegundos) pelos busy-loops das tasks no último intervalo
static volatile uint64_t busy_us_accumulator = 0;

// proteger updates simples
static SemaphoreHandle_t semMetrics = NULL;

// helpers pra contabilizar busy time (chamar sempre logo antes do cpu_tight_loop_us)
static inline void acc_busy_us(uint32_t us)
{
    // tentamos proteger a escrita com mutex se não estivermos em ISR
    if (semMetrics && xPortIsInsideInterrupt() == pdFALSE) {
        if (xSemaphoreTake(semMetrics, 0) == pdTRUE) {
            busy_us_accumulator += us;
            xSemaphoreGive(semMetrics);
            return;
        }
    }
    // fallback (não bloquear)
    busy_us_accumulator += us;
}

// ====== Política de prioridade ======
typedef enum { POLICY_RM = 0, POLICY_DM = 1, POLICY_CUSTOM = 2 } sched_policy_t;
static sched_policy_t g_policy = POLICY_RM;

// Função para tentar forçar a CPU para mhz (requer CONFIG_PM_ENABLE)
static void set_cpu_freq_mhz(int mhz)
{
#ifdef CONFIG_PM_ENABLE
    esp_pm_config_esp32_t pm_cfg = {
        .max_cpu_freq_mhz = mhz,
        .min_cpu_freq_mhz = mhz,
#if CONFIG_IDF_TARGET_ESP32
        .light_sleep_enable = false
#endif
    };
    esp_err_t err = esp_pm_configure(&pm_cfg);
    if (err == ESP_OK) {
        ESP_LOGI(TAG, "CPU freq setada para %d MHz via esp_pm_configure.", mhz);
    } else {
        ESP_LOGW(TAG, "Falha ao setar freq (err=%d).", err);
    }
#else
    ESP_LOGW(TAG, "Power management (CONFIG_PM_ENABLE) não habilitado: não foi possível alterar freq por código.");
    ESP_LOGW(TAG, "Altere em menuconfig -> Component config -> Power Management para habilitar.");
#endif
}

// atribui prioridades (inteiros do FreeRTOS) com base na política escolhida
static void assign_and_log_priorities(void)
{
    // Prioridades base
    int prio_enc = PRIO_ENC_DEF;
    int prio_ctrl = PRIO_CTRL_DEF;
    int prio_sort = PRIO_SORT_DEF;
    int prio_estop = PRIO_ESTOP_DEF;

    if (g_policy == POLICY_RM) {
        // Rate Monotonic: tarefa com menor período -> maior prioridade
        prio_enc = 6;   // ENC (5 ms)
        prio_ctrl = 5;  // CTRL (reage frequentemente)
        prio_sort = 4;  // SORT (20 ms)
        prio_estop = 7;
        ESP_LOGI(TAG, "Política: Rate Monotonic (RM) aplicada.");
    } else if (g_policy == POLICY_DM) {
        // Deadline Monotonic (assumindo deadlines): similar ao RM neste exemplo
        prio_enc = 6;
        prio_ctrl = 5;
        prio_sort = 4;
        prio_estop = 7;
        ESP_LOGI(TAG, "Política: Deadline Monotonic (DM) aplicada.");
    } else {
        // Custom: prioretize SORT, safety top
        prio_sort = 6;
        prio_enc = 4;
        prio_ctrl = 3;
        prio_estop = 8;
        ESP_LOGI(TAG, "Política: Customizada aplicada (SORT priorizado).");
    }

    // se já existem handles, atualiza prioridades com vTaskPrioritySet
    if (hENC) vTaskPrioritySet(hENC, prio_enc);
    if (hCTRL) vTaskPrioritySet(hCTRL, prio_ctrl);
    if (hSORT) vTaskPrioritySet(hSORT, prio_sort);
    if (hSAFE) vTaskPrioritySet(hSAFE, prio_estop);

    ESP_LOGI(TAG, "Prioridades -> ENC=%d CTRL=%d SORT=%d SAFETY=%d",
             prio_enc, prio_ctrl, prio_sort, prio_estop);
}

// ====== Tasks (mesma lógica, com instrumentação) ======

// ENC_SENSE
static void task_enc_sense(void *arg)
{
    TickType_t next = xTaskGetTickCount();
    TickType_t T = pdMS_TO_TICKS(ENC_T_MS);
    if (T == 0) T = 1;
    for (;;) {
        // inicio do processamento (simula sensor + filtro)
        float err = g_belt.set_rpm - g_belt.rpm;
        g_belt.rpm += 0.05f * err;
        g_belt.pos_mm += (g_belt.rpm / 60.0f) * (ENC_T_MS / 1000.0f) * 100.0f;

        // limites
        if (g_belt.rpm > 200.0f) g_belt.rpm = 200.0f;
        if (g_belt.set_rpm > 200.0f) g_belt.set_rpm = 200.0f;

        // contabilizar WCET usado (700 us)
        acc_busy_us(700);
        cpu_tight_loop_us(700);

        if (hCtrlNotify) xTaskNotifyGive(hCtrlNotify);
        vTaskDelayUntil(&next, T);

        // (variáveis de diagnóstico removidas/neutralizadas para evitar warnings)
    }
}

// SPD_CTRL
static void task_spd_ctrl(void *arg)
{
    float kp = 0.4f, ki = 0.1f, integ = 0.f;
    const int64_t deadline_us_rel = 7000; // exemplo 7 ms deadline
    for (;;) {
        ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
        int64_t start = esp_timer_get_time();

        float err = g_belt.set_rpm - g_belt.rpm;
        integ += err * (ENC_T_MS / 1000.0f);
        float u = kp * err + ki * integ;
        g_belt.set_rpm += 0.1f * u;

        // limites
        if (g_belt.set_rpm > 200.0f) g_belt.set_rpm = 200.0f;
        if (g_belt.set_rpm < 0.0f) g_belt.set_rpm = 0.0f;

        // contabilizar WCET (1200 us)
        acc_busy_us(1200);
        cpu_tight_loop_us(1200);

        if (xSemaphoreTake(semHMI, 0) == pdTRUE) {
            ESP_LOGI(TAG, "[HMI] Interação detectada. rpm=%.1f set=%.1f pos=%.1fmm",
                     g_belt.rpm, g_belt.set_rpm, g_belt.pos_mm);
        }

        // deadline check: consider arrival time = notification time (aprox)
        int64_t end = esp_timer_get_time();
        if ((end - start) > deadline_us_rel) {
            misses_ctrl++;
        }
    }
}

// SORT_ACT
static void task_sort_act(void *arg)
{
    sort_evt_t ev;
    const int64_t deadline_rel_us = 20000; // 20 ms deadline
    for (;;) {
        if (xQueueReceive(qSort, &ev, portMAX_DELAY) == pdTRUE) {
            int64_t t0 = esp_timer_get_time();

            // actuate (WCET 700 us)
            acc_busy_us(700);
            cpu_tight_loop_us(700);

            int64_t dt = esp_timer_get_time() - t0;
            int64_t lat = t0 - ev.t_evt_us;
            ESP_LOGI(TAG, "[SORT] Objeto detectado. evt_ts=%lld lat=%lld us act=%lld us",
                     (long long)ev.t_evt_us, (long long)lat, (long long)dt);

            // deadline check: compare finish time vs ev.deadline_us
            int64_t finish = esp_timer_get_time();
            if (finish > ev.deadline_us) {
                misses_sort++;
            }

            // também, se latency > deadline_rel, conta miss
            if (lat > deadline_rel_us) {
                misses_sort++;
            }
        }
    }
}

// SAFETY_TASK
static void task_safety(void *arg)
{
    for (;;) {
        if (xSemaphoreTake(semEStop, portMAX_DELAY) == pdTRUE) {
            int64_t t0 = esp_timer_get_time();
            g_belt.set_rpm = 0.f;

            acc_busy_us(900);
            cpu_tight_loop_us(900);

            int64_t dt = esp_timer_get_time() - t0;
            ESP_LOGW(TAG, "[E-STOP] Emergência! Esteira parada. dur=%lld us", (long long)dt);
        }
    }
}

// HEARTBEAT
static void task_heartbeat(void *arg)
{
    for (;;) {
        ESP_LOGI(TAG, "[STATUS] rpm=%.1f | set=%.1f | pos=%.1f mm | misses(enc=%u sort=%u ctrl=%u)",
                 g_belt.rpm, g_belt.set_rpm, g_belt.pos_mm, (unsigned)misses_enc, (unsigned)misses_sort, (unsigned)misses_ctrl);
        vTaskDelay(pdMS_TO_TICKS(200)); // mais rápido p/ ver rampa
    }
}

// Polling dos touch pads
static void task_touch_poll(void *arg)
{
    uint32_t sum0 = 0, sum4 = 0, sum9 = 0;
    uint16_t tmp0 = 0, tmp4 = 0, tmp9 = 0;
    for (int i = 0; i < TOUCH_BASELINE_SAMPLES; ++i) {
        touch_pad_read_filtered(TP_OBJ, &tmp0);
        touch_pad_read_filtered(TP_HMI, &tmp4);
        touch_pad_read_filtered(TP_ESTOP, &tmp9);
        sum0 += tmp0; sum4 += tmp4; sum9 += tmp9;
        vTaskDelay(pdMS_TO_TICKS(50));
    }
    uint16_t base0 = sum0 / TOUCH_BASELINE_SAMPLES;
    uint16_t base4 = sum4 / TOUCH_BASELINE_SAMPLES;
    uint16_t base9 = sum9 / TOUCH_BASELINE_SAMPLES;

    uint16_t thresh0 = (uint16_t)(base0 * TOUCH_THRESH_FRACT);
    uint16_t thresh4 = (uint16_t)(base4 * TOUCH_THRESH_FRACT);
    uint16_t thresh9 = (uint16_t)(base9 * TOUCH_THRESH_FRACT);

    ESP_LOGI(TAG, "Touch baseline: T0=%u T4=%u T9=%u", base0, base4, base9);
    ESP_LOGI(TAG, "Touch thresholds: T0=%u T4=%u T9=%u (fract=%.2f)",
             thresh0, thresh4, thresh9, TOUCH_THRESH_FRACT);

    bool prev0 = false, prev4 = false, prev9 = false;

    for (;;) {
        touch_pad_read_filtered(TP_OBJ, &tmp0);
        touch_pad_read_filtered(TP_HMI, &tmp4);
        touch_pad_read_filtered(TP_ESTOP, &tmp9);

        bool cur0 = (tmp0 < thresh0);
        bool cur4 = (tmp4 < thresh4);
        bool cur9 = (tmp9 < thresh9);

        if (cur0 && !prev0) {
            sort_evt_t ev;
            ev.t_evt_us = esp_timer_get_time();
            // define deadline (evt + 20 ms)
            ev.deadline_us = ev.t_evt_us + (20LL * 1000LL);
            xQueueSend(qSort, &ev, 0);
            ESP_LOGI(TAG, "[POLL] T0 touch -> queued SORT");
        }
        if (cur4 && !prev4) {
            xSemaphoreGive(semHMI);
            ESP_LOGI(TAG, "[POLL] T4 touch -> HMI");
        }
        if (cur9 && !prev9) {
            xSemaphoreGive(semEStop);
            ESP_LOGI(TAG, "[POLL] T9 touch -> E-STOP");
        }

        prev0 = cur0; prev4 = cur4; prev9 = cur9;
        vTaskDelay(pdMS_TO_TICKS(TOUCH_POLL_MS));
    }
}

// Touch setup
static void touch_pads_setup_for_polling(void)
{
    ESP_ERROR_CHECK(touch_pad_init());
    touch_pad_config(TP_OBJ, 0);
    touch_pad_config(TP_HMI, 0);
    touch_pad_config(TP_ESTOP, 0);
    ESP_ERROR_CHECK(touch_pad_filter_start(TOUCH_FILTER_CYCLES));
    touch_pad_clear_status();
    ESP_LOGI(TAG, "Touch pads iniciados para polling (filtro ativado).");
}

// Monitor de métricas -> imprime misses e utilização CPU estimada a cada segundo
static void task_metrics_monitor(void *arg)
{
    const int interval_ms = 1000;
    for (;;) {
        vTaskDelay(pdMS_TO_TICKS(interval_ms));
        uint64_t acc = 0;
        if (semMetrics && xSemaphoreTake(semMetrics, (TickType_t)10) == pdTRUE) {
            acc = busy_us_accumulator;
            busy_us_accumulator = 0;
            xSemaphoreGive(semMetrics);
        } else {
            // fallback sem mutex
            acc = busy_us_accumulator;
            busy_us_accumulator = 0;
        }
        // utilização estimada = acc / (interval_ms * 1000) * 100%
        float util = ((float)acc / (float)(interval_ms * 1000LL)) * 100.0f;
        ESP_LOGI(TAG, "[METRICS] intervalo=%d ms busy_us=%llu util_estimada=%.2f%% misses: ENC=%u SORT=%u CTRL=%u",
                 interval_ms, (unsigned long long)acc, util, (unsigned)misses_enc, (unsigned)misses_sort, (unsigned)misses_ctrl);
    }
}

// app_main
void app_main(void)
{
    ESP_LOGI(TAG, "=== Sistema ESTEIRA iniciado ===");

#if configUSE_PREEMPTION
    ESP_LOGI(TAG, "FreeRTOS: preempção ATIVADA");
#else
    ESP_LOGI(TAG, "FreeRTOS: preempção DESATIVADA");
#endif

#if configUSE_TIME_SLICING
    ESP_LOGI(TAG, "FreeRTOS: timeslicing ATIVADO");
#else
    ESP_LOGI(TAG, "FreeRTOS: timeslicing DESATIVADO");
#endif

    // inicializa semáforos/filas/metrics
    semEStop = xSemaphoreCreateBinary();
    semHMI   = xSemaphoreCreateBinary();
    qSort    = xQueueCreate(16, sizeof(sort_evt_t));
    semMetrics = xSemaphoreCreateMutex();

    // setar política de teste
#if TEST_POLICY == 0
    g_policy = POLICY_RM;
#elif TEST_POLICY == 1
    g_policy = POLICY_DM;
#else
    g_policy = POLICY_CUSTOM;
#endif

    // tentar setar CPU freq (requer CONFIG_PM_ENABLE)
    set_cpu_freq_mhz(TEST_CPU_FREQ_MHZ);
    ESP_LOGI(TAG, "Forçando tasks para rodar no core 0 (single-core).");

    // Cria tasks PINNED to core 0 -> garante execução em único núcleo
    xTaskCreatePinnedToCore(task_safety,   "SAFETY",   STK, NULL, PRIO_ESTOP_DEF, &hSAFE, 0);
    xTaskCreatePinnedToCore(task_enc_sense,"ENC_SENSE",STK, NULL, PRIO_ENC_DEF,   &hENC,  0);
    xTaskCreatePinnedToCore(task_spd_ctrl, "SPD_CTRL", STK, NULL, PRIO_CTRL_DEF,  &hCTRL, 0);
    xTaskCreatePinnedToCore(task_sort_act, "SORT_ACT", STK, NULL, PRIO_SORT_DEF,  &hSORT, 0);
    xTaskCreatePinnedToCore(task_heartbeat,"HEARTBEAT",2048, NULL, PRIO_HEART_DEF, &hHEART, 0);

    hCtrlNotify = hCTRL;

    touch_pads_setup_for_polling();
    xTaskCreatePinnedToCore(task_touch_poll, "TOUCH_POLL", 3072, NULL, PRIO_TOUCH_DEF, &hTOUCH, 0);

    // Aplica prioridades com base na política escolhida (pós-criação das tasks)
    assign_and_log_priorities();

    // Start metrics monitor
    xTaskCreatePinnedToCore(task_metrics_monitor, "METRICS", 2048, NULL, 2, NULL, 0);

    ESP_LOGI(TAG, "=== Setup completo ===");
}
